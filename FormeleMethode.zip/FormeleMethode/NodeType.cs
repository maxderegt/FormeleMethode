﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FormeleMethode
{
	//enum for the Type of node
	public enum NodeType
	{
		StartNode = 0,
		EndNode = 1,
		NormalNode = 2
	}
}