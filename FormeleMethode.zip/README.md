# FormeleMethode

wat we missen:

1b (even hans nagevraagd) (extra)

2a. 
Woorden genereren aan de hand van de ingevoerde reguliere expressie 
Woorden genereren die niet in de taal zitten

3a
begint met xyz
eindigt op xyz
bevat xyz
3b (extra)


6. 
Minimalisatie (via reverse)

automatisch pdf openen
